#!/bin/bash -e

rm -fr /usr/share/nginx/html/*
